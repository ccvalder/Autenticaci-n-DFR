from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets
from .models import Libro
from .serializers import LibroSerializer
from rest_framework.permissions import IsAuthenticatedOrReadOnly

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.authtoken.models import Token
from rest_framework.response import Response

class LibroViewSet(viewsets.ModelViewSet):
    queryset = Libro.objects.all()
    serializer_class = LibroSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def regenerar_token(request):
    # Eliminar token existente
    request.user.auth_token.delete()
    # Crear nuevo token
    token = Token.objects.create(user=request.user)

    return Response({'token': token.key})