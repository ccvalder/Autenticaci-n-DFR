from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import LibroViewSet, regenerar_token

router = DefaultRouter()
router.register(r'libros', LibroViewSet)

# URLs personalizadas
urlpatterns = [
    path('regenerar-token/', regenerar_token, name='regenerar_token'),
]

# Combinar router + personalizadas
urlpatterns += router.urls