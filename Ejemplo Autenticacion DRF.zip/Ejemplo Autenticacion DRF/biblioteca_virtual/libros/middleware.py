# libros/middleware.py
from datetime import timedelta
from django.utils import timezone
from rest_framework.authtoken.models import Token

class TokenExpirationMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Verificar si hay un token en la solicitud o request
        token = getattr(request, 'auth', None)
        if token:
            if token.created < timezone.now() - timedelta(days=30):
                token.delete()
        response = self.get_response(request)
        return response
